#include "StringFindReplaceCommand.h"
#include "AbsAudioFile.h"

void StringFindReplaceCommand::execute(AbsAudioFile & f)
{
	// Declencher l'execution de la commande
	// A COMPLETER...
	//yooooooooo i need help
	f.accept(m_visitor);
}
